package Patrones;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author anton
 */

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;
import java.util.*;

public class Frame extends JFrame{
    
    private JPanel pnl;
    private JLabel etqTitle1, etqTitle2, etqSubtitle, etqSubtitle2, etqReinas, etqPoblacion, etqGeneracion;
    private JLabel etqSep1, etqSep2, etqSep3, etqSepTitle, etqFondo;
    private ImageIcon imgFondo;
    private JTextField txtReinas, txtPoblacion, txtGeneracion;
    private JButton btnPatronOri, btnGuardar, btnRecuperar, btnVer;
    private JButton btnPatronRec, btnReconocer;
    private JLabel etqPatron;
    
    int filas = 5;
    int columnas = 8;
    int tam = filas * columnas;
    
         
    ArrayList<JButton> btnPatronesOrig = new ArrayList<>();
    ArrayList<JLabel> etqPatronesFin = new ArrayList<>();
    ArrayList<int[]> patrones = new ArrayList<>();
    int[] patronOrig = new int[tam];
    int[] patronRecu = new int[tam];
    
    int[] patronRecuMAX = new int[tam];
    int[] patronRecuMIN = new int[tam];
    int[] patronRecuFin = new int[tam];
    
    ArrayList<int[][]> matricesP = new ArrayList<>();
    int[][] memoriaMAX = new int[tam][tam];
    int[][] memoriaMIN = new int[tam][tam];

    
    
    //Constructor
    public Frame(){
        setTitle("Algoritmo Genetico - Problema de la 8 Reinas");
        setSize(750,450);
        setResizable(false);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);        
        initComponets();
        setVisible(true);
    }
    
    public void initComponets(){
        
        //CODIGO PANEL
        pnl = new JPanel();
        this.getContentPane().add(pnl);
        pnl.setLayout(null);
        
        int cont = 0;
        for(int i=0 ; i<columnas ; i++){
            for(int j=0 ; j<filas ; j++){
                btnPatronOri = new JButton();
                btnPatronOri.addActionListener(new EventoBoton(patronOrig));
                btnPatronOri.setBounds(0+(j*30),0+(i*30),30,30);
                btnPatronOri.setName(String.valueOf(cont));
                pnl.add(btnPatronOri);
                cont++;
                
                btnPatronesOrig.add(btnPatronOri);
            }
        }
        
        cont = 0;
        for(int i=0 ; i<columnas ; i++){
            for(int j=0 ; j<filas ; j++){
                btnPatronRec = new JButton();
                btnPatronRec.addActionListener(new EventoBoton(patronRecu));
                btnPatronRec.setBounds(250+(j*30),0+(i*30),30,30);
                btnPatronRec.setName(String.valueOf(cont));
                pnl.add(btnPatronRec);
                cont++;
            }
        }
        
        cont = 0;
        for(int i=0 ; i<columnas ; i++){
            for(int j=0 ; j<filas ; j++){
                etqPatron = new JLabel();
                //etqPatron.addActionListener(new EventoBoton(patronRecu));
                etqPatron.setOpaque(true);
                etqPatron.setBackground(Color.WHITE);
                etqPatron.setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.BLACK));
                etqPatron.setBounds(500+(j*30),0+(i*30),30,30);
                etqPatron.setName(String.valueOf(cont));
                pnl.add(etqPatron);
                cont++;
                
                etqPatronesFin.add(etqPatron);
            }
        }
        btnGuardar = new JButton("Guardar Patrón");
        btnGuardar.addActionListener(new EventoGuardar());
        btnGuardar.setBounds(10,300,150,30);
        pnl.add(btnGuardar);
        
        btnRecuperar = new JButton("Recuperar Patrón");
        btnRecuperar.addActionListener(new EventoRecuperar());
        btnRecuperar.setBounds(400,150,100,30);
        pnl.add(btnRecuperar);
        
        btnVer = new JButton("Ver");
        btnVer.addActionListener(new EventoVer());
        btnVer.setBounds(400,300,100,30);
        pnl.add(btnVer);
        
    }
    
    //CODIGO EVENTO ACTION
    public class EventoBoton implements ActionListener{
        int[] patron;
        
        EventoBoton(int[] patron){
            this.patron = patron;
        }
        
        @Override
        public void actionPerformed(ActionEvent ev){
            JButton btn = (JButton)ev.getSource();
            int num = Integer.parseInt(btn.getName());
            //System.out.println(name);
            if(patron[num] == 0){ 
                patron[num] = 1;
                btn.setBackground(Color.BLACK);
            }else{
                patron[num] = 0;
                btn.setBackground(Color.WHITE);
            }
        }//evento
    }//clase interna
    
    //CODIGO EVENTO ACTION
    public class EventoGuardar implements ActionListener{
        @Override
        public void actionPerformed(ActionEvent ev){    
            int[] patronO = patronOrig.clone();
            patrones.add(patronO);
            limpiarPatron(patronOrig, btnPatronesOrig);
            
            for(int i=0; i<patrones.size(); i++){
                int[][] matrizP = new int[tam][tam];
                for(int j=0; j<tam; j++){
                    for(int k=0; k<tam; k++){
                        matrizP[j][k] = operacionALFA(patrones.get(i)[j],patrones.get(i)[k]);
                    }    
                }
                matricesP.add(matrizP);
            }
            
            ArrayList<Integer> valorMem = new ArrayList<>();
            for(int j=0; j<tam; j++){
                for(int k=0; k<tam; k++){
                    for(int i=0; i<matricesP.size(); i++){
                        valorMem.add(matricesP.get(i)[j][k]);
                    }
                    memoriaMAX[j][k]= Collections.max(valorMem);
                    memoriaMIN[j][k]= Collections.min(valorMem);
                    valorMem.clear();
                }
            }
        }//evento
    }//clase interna
    
    //CODIGO EVENTO ACTION
    public class EventoRecuperar implements ActionListener{
        @Override
        public void actionPerformed(ActionEvent ev){
            int[] patronR = patronRecu.clone();
            
            int[][] matrizRMAX = new int[tam][tam];
            for(int j=0; j<tam; j++){
                for(int k=0; k<tam; k++){
                    matrizRMAX[j][k] = operacionBETA(memoriaMAX[j][k],patronR[k]);
                }    
            }
            
            int[][] matrizRMIN = new int[tam][tam];
            for(int j=0; j<tam; j++){
                for(int k=0; k<tam; k++){
                    matrizRMIN[j][k] = operacionBETA(memoriaMIN[j][k],patronR[k]);
                }    
            }
            
            int val = 0;
            int valPatron = 0;
            for(int j=0; j<tam; j++){
                val = matrizRMAX[j][0];
                for(int k=1; k<tam; k++){
                    if(val==1 && matrizRMAX[j][k]==1)
                        valPatron = 1;
                    else
                        valPatron = 0;
                    val = valPatron;
                }    
                patronRecuMAX[j] = valPatron;
            }
            
            for(int j=0; j<tam; j++){
                val = matrizRMIN[j][0];
                for(int k=1; k<tam; k++){
                    if(val==0 && matrizRMIN[j][k]==0)
                        valPatron = 0;
                    else
                        valPatron = 1;
                    val = valPatron;
                }    
                patronRecuMIN[j] = valPatron;
            }
            
            for(int i=0 ; i<patrones.size() ; i++){
                if(Arrays.equals(patrones.get(i), patronRecuMAX)){
                    patronRecuFin = patronRecuMAX;
                    break;
                }
                else if(Arrays.equals(patrones.get(i), patronRecuMIN)){
                    patronRecuFin = patronRecuMIN;
                    break;
                }
            }
            
            for(int i=0; i<tam; i++){
                if(patronRecuFin[i]==0)
                    etqPatronesFin.get(i).setBackground(Color.WHITE);
                else
                    etqPatronesFin.get(i).setBackground(Color.BLACK);
            }
            
            System.out.println("Patron Final");
            for(int j=0; j<columnas; j++){
                for(int k=0; k<filas; k++){
                    System.out.print(patronRecuFin[k+(j*5)]);
                }
                System.out.println("");
            }
            System.out.print("\n");
            
            
            
        }//evento
    }//clase interna
    
    //CODIGO EVENTO ACTION
    public class EventoVer implements ActionListener{
        @Override
        public void actionPerformed(ActionEvent ev){
            for(int j=0; j<4; j++){
                for(int k=0; k<4; k++){
                    System.out.print(memoriaMAX[j][k]);
                }
                System.out.println("");
            }
             System.out.println("\n");
            for(int j=0; j<4; j++){
                for(int k=0; k<4; k++){
                    System.out.print(memoriaMIN[j][k]);
                }
                System.out.println("");
            }
        }//evento
    }//clase interna
    
    
    public void limpiarPatron(int[] patron, ArrayList<JButton> botones){
        for(int i=0; i<patron.length ; i++){
            patron[i] = 0;
            botones.get(i).setBackground(Color.WHITE);
        }
    }
    
    public int operacionALFA(int x, int y){
        int alfa=0;
        if(x==0 && y==0)
            alfa = 1;
        else if(x==0 && y==1)
            alfa = 0;
        else if(x==1 && y==0)
            alfa = 2;
        else if(x==1 && y==1)
            alfa = 1;
        
        return alfa;
    }
    
    public int operacionBETA(int x, int y){
        int beta = 0;
        if(x==0 && y==0)
            beta = 0;
        else if(x==0 && y==1)
            beta = 0;
        else if(x==1 && y==0)
            beta = 0;
        else if(x==1 && y==1)
            beta = 1;
        else if(x==2 && y==0)
            beta = 1;
        else if(x==2 && y==1)
            beta = 1;
        
        return beta;
    }
}
